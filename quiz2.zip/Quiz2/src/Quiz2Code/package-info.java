/**
 * 
 */
/**
 * @author ryukasun
 *
 */
package Quiz2Code;